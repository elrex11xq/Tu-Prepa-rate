import type { NextFunction, Request, Response } from 'express';

type AsyncRouteHandler<Req extends Request = Request> = (
  req: Req,
  res: Response,
  next: NextFunction,
) => Promise<void>;

/**
 * Envuelve un controlador async para propagar automáticamente
 * cualquier excepción al middleware de manejo de errores (next(err)),
 * evitando bloques try/catch repetidos en cada endpoint.
 */
export function asyncHandler<Req extends Request = Request>(
  handler: AsyncRouteHandler<Req>,
): (req: Req, res: Response, next: NextFunction) => void {
  return (req, res, next) => {
    handler(req, res, next).catch(next);
  };
}
