import jwt, { type SignOptions } from 'jsonwebtoken';
import { randomUUID } from 'node:crypto';
import { env } from '@config/env';
import type { UserRole } from '@prisma/client';
import { UnauthorizedError } from '@common/errors/AppError';

export interface AccessTokenPayload {
  userId: string;
  role: UserRole;
}

export interface RefreshTokenPayload {
  userId: string;
  jti: string; // identificador único del refresh token, usado para revocación/rotación
}

/**
 * Access token: de vida corta, viaja en cada request (Authorization: Bearer).
 * Nunca se persiste en base de datos — es puramente stateless.
 */
export function signAccessToken(payload: AccessTokenPayload): string {
  return jwt.sign(payload, env.JWT_ACCESS_SECRET, {
    expiresIn: env.JWT_ACCESS_EXPIRES_IN,
  } as SignOptions);
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  try {
    return jwt.verify(token, env.JWT_ACCESS_SECRET) as AccessTokenPayload;
  } catch {
    throw new UnauthorizedError('Token de acceso inválido o expirado');
  }
}

/**
 * Refresh token: de vida larga. Su hash (no el valor en claro) se persiste en
 * `RefreshToken` para poder revocarlo y detectar reutilización tras rotación
 * (si un token ya rotado se vuelve a usar, es señal de robo de token).
 */
export function generateRefreshTokenJti(): string {
  return randomUUID();
}

export function signRefreshToken(payload: RefreshTokenPayload): string {
  return jwt.sign(payload, env.JWT_REFRESH_SECRET, {
    expiresIn: env.JWT_REFRESH_EXPIRES_IN,
  } as SignOptions);
}

export function verifyRefreshToken(token: string): RefreshTokenPayload {
  try {
    return jwt.verify(token, env.JWT_REFRESH_SECRET) as RefreshTokenPayload;
  } catch {
    throw new UnauthorizedError('Refresh token inválido o expirado');
  }
}
