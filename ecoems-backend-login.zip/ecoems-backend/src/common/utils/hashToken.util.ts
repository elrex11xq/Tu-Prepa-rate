import { createHash } from 'node:crypto';

/**
 * Hash determinístico (SHA-256) usado ÚNICAMENTE para refresh tokens.
 * A diferencia de las contraseñas, un refresh token ya es un secreto de alta
 * entropía generado por el servidor (no elegido por el usuario), por lo que
 * un hash rápido es apropiado aquí: lo que buscamos es no guardar el secreto
 * en claro en la base de datos, no protegernos de ataques de diccionario.
 */
export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}
