import argon2 from 'argon2';

/**
 * Argon2id: ganador del Password Hashing Competition, resistente a ataques
 * de GPU/ASIC y a side-channel timing attacks (a diferencia de Argon2i/Argon2d puros).
 * Parámetros conservadores para un servicio web (ajustar tras medir en el hardware real).
 */
const ARGON2_OPTIONS = {
  type: argon2.argon2id,
  memoryCost: 19456, // ~19 MB
  timeCost: 2,
  parallelism: 1,
} as const;

export async function hashPassword(plainPassword: string): Promise<string> {
  return argon2.hash(plainPassword, ARGON2_OPTIONS);
}

export async function verifyPassword(hash: string, plainPassword: string): Promise<boolean> {
  try {
    return await argon2.verify(hash, plainPassword);
  } catch {
    // Hash corrupto/formato inesperado: tratar como credencial inválida, no como crash.
    return false;
  }
}
