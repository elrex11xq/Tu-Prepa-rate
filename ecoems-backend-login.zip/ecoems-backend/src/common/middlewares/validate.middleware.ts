import type { NextFunction, Request, Response } from 'express';
import { ZodError, type ZodTypeAny } from 'zod';
import { ValidationError } from '@common/errors/AppError';

interface ValidationSchemas {
  body?: ZodTypeAny;
  params?: ZodTypeAny;
  query?: ZodTypeAny;
}

/**
 * Middleware de validación de entrada basado en Zod.
 * Valida y REEMPLAZA req.body/params/query con los datos ya parseados
 * (con defaults y coerciones aplicadas), garantizando tipado confiable
 * en los controladores subsecuentes.
 */
export function validate(schemas: ValidationSchemas) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    try {
      if (schemas.body) {
        req.body = schemas.body.parse(req.body);
      }
      if (schemas.params) {
        req.params = schemas.params.parse(req.params);
      }
      if (schemas.query) {
        req.query = schemas.query.parse(req.query);
      }
      next();
    } catch (err) {
      if (err instanceof ZodError) {
        next(new ValidationError(err.flatten()));
        return;
      }
      next(err);
    }
  };
}
