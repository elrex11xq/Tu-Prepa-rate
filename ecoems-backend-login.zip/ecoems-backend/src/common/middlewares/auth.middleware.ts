import type { NextFunction, Request, Response } from 'express';
import type { UserRole } from '@prisma/client';
import { verifyAccessToken } from '@common/utils/jwt.util';
import { ForbiddenError, UnauthorizedError } from '@common/errors/AppError';

/**
 * Exige un access token JWT válido en el header `Authorization: Bearer <token>`.
 * Adjunta `req.user = { userId, role }` para uso en controladores/servicios posteriores.
 */
export function requireAuth(req: Request, _res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;

  if (!authHeader?.startsWith('Bearer ')) {
    throw new UnauthorizedError('Encabezado de autorización faltante o mal formado');
  }

  const token = authHeader.slice('Bearer '.length).trim();
  if (!token) {
    throw new UnauthorizedError('Token de acceso faltante');
  }

  const payload = verifyAccessToken(token);
  req.user = { userId: payload.userId, role: payload.role };
  next();
}

/**
 * Guard de autorización por rol. Debe usarse DESPUÉS de `requireAuth`.
 * Ejemplo: router.post('/admin/x', requireAuth, requireRole('ADMIN'), handler)
 */
export function requireRole(...allowedRoles: UserRole[]) {
  return (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.user) {
      throw new UnauthorizedError();
    }
    if (!allowedRoles.includes(req.user.role)) {
      throw new ForbiddenError('Tu rol no tiene permiso para acceder a este recurso');
    }
    next();
  };
}
