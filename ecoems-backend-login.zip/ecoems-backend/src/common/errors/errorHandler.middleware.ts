import type { NextFunction, Request, Response } from 'express';
import { Prisma } from '@prisma/client';
import { ZodError } from 'zod';
import { AppError } from './AppError';
import { logger } from '@config/logger';
import { env } from '@config/env';

interface ErrorResponseBody {
  success: false;
  error: {
    code: string;
    message: string;
    details?: unknown;
  };
}

/**
 * Middleware central de manejo de errores.
 * Debe registrarse como el ÚLTIMO middleware de la app (app.ts).
 * Traduce cualquier excepción (de dominio, de Prisma, de Zod o inesperada)
 * a una respuesta HTTP consistente, sin filtrar detalles internos en producción.
 */
export function errorHandlerMiddleware(
  err: unknown,
  req: Request,
  res: Response,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _next: NextFunction,
): void {
  // 1. Errores de dominio ya tipados
  if (err instanceof AppError) {
    if (!err.isOperational) {
      logger.error({ err, path: req.path }, 'Error NO operacional capturado');
    } else {
      logger.warn({ errorCode: err.errorCode, path: req.path }, err.message);
    }

    const body: ErrorResponseBody = {
      success: false,
      error: { code: err.errorCode, message: err.message, details: err.details },
    };
    res.status(err.statusCode).json(body);
    return;
  }

  // 2. Errores de validación de Zod (por si algún middleware no los transformó antes)
  if (err instanceof ZodError) {
    res.status(422).json({
      success: false,
      error: { code: 'VALIDATION_ERROR', message: 'Error de validación', details: err.flatten() },
    } satisfies ErrorResponseBody);
    return;
  }

  // 3. Errores conocidos de Prisma (constraint únicos, FK, registro no encontrado, etc.)
  if (err instanceof Prisma.PrismaClientKnownRequestError) {
    let statusCode = 500;
    let message = 'Error de base de datos';

    switch (err.code) {
      case 'P2002':
        statusCode = 409;
        message = `El valor ya existe (campo: ${String(err.meta?.['target'])})`;
        break;
      case 'P2025':
        statusCode = 404;
        message = 'Registro no encontrado';
        break;
      case 'P2003':
        statusCode = 409;
        message = 'Violación de llave foránea';
        break;
      default:
        logger.error({ err }, 'Error Prisma no mapeado explícitamente');
    }

    res.status(statusCode).json({
      success: false,
      error: { code: `PRISMA_${err.code}`, message },
    } satisfies ErrorResponseBody);
    return;
  }

  // 4. Cualquier otro error no anticipado: NUNCA exponer el stack en producción
  logger.error({ err, path: req.path }, 'Error inesperado no controlado');

  res.status(500).json({
    success: false,
    error: {
      code: 'INTERNAL_ERROR',
      message:
        env.NODE_ENV === 'production'
          ? 'Ocurrió un error interno. Intenta de nuevo más tarde.'
          : err instanceof Error
            ? err.message
            : 'Error desconocido',
    },
  } satisfies ErrorResponseBody);
}

/** Middleware para rutas no encontradas (404) */
export function notFoundMiddleware(req: Request, res: Response): void {
  res.status(404).json({
    success: false,
    error: { code: 'ROUTE_NOT_FOUND', message: `Ruta no encontrada: ${req.method} ${req.originalUrl}` },
  } satisfies ErrorResponseBody);
}
