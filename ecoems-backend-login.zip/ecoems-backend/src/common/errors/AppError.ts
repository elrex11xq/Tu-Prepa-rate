/**
 * Error base de la aplicación.
 * `isOperational = true` indica un error esperado (ej. validación, 404, negocio)
 * que se puede comunicar de forma segura al cliente.
 * Errores NO operacionales (bugs, fallos de infraestructura) se registran
 * pero se ocultan del cliente en producción.
 */
export class AppError extends Error {
  public readonly statusCode: number;
  public readonly isOperational: boolean;
  public readonly errorCode: string;
  public readonly details?: unknown;

  constructor(
    message: string,
    statusCode = 500,
    errorCode = 'INTERNAL_ERROR',
    isOperational = true,
    details?: unknown,
  ) {
    super(message);
    this.statusCode = statusCode;
    this.errorCode = errorCode;
    this.isOperational = isOperational;
    this.details = details;
    Object.setPrototypeOf(this, new.target.prototype);
    Error.captureStackTrace(this, this.constructor);
  }
}

export class BadRequestError extends AppError {
  constructor(message = 'Solicitud inválida', details?: unknown) {
    super(message, 400, 'BAD_REQUEST', true, details);
  }
}

export class UnauthorizedError extends AppError {
  constructor(message = 'No autenticado') {
    super(message, 401, 'UNAUTHORIZED', true);
  }
}

export class ForbiddenError extends AppError {
  constructor(message = 'No tienes permiso para realizar esta acción') {
    super(message, 403, 'FORBIDDEN', true);
  }
}

export class NotFoundError extends AppError {
  constructor(resource = 'Recurso') {
    super(`${resource} no encontrado`, 404, 'NOT_FOUND', true);
  }
}

export class ConflictError extends AppError {
  constructor(message = 'Conflicto con el estado actual del recurso') {
    super(message, 409, 'CONFLICT', true);
  }
}

export class ValidationError extends AppError {
  constructor(details: unknown) {
    super('Error de validación de datos', 422, 'VALIDATION_ERROR', true, details);
  }
}

export class TooManyRequestsError extends AppError {
  constructor(message = 'Demasiadas solicitudes, intenta más tarde') {
    super(message, 429, 'TOO_MANY_REQUESTS', true);
  }
}

/** Errores específicos de dominio de juego/negocio */
export class InsufficientLivesError extends AppError {
  constructor() {
    super('No tienes vidas suficientes para iniciar esta sesión', 409, 'INSUFFICIENT_LIVES', true);
  }
}

export class SubscriptionRequiredError extends AppError {
  constructor(message = 'Esta función requiere una suscripción activa') {
    super(message, 402, 'SUBSCRIPTION_REQUIRED', true);
  }
}
