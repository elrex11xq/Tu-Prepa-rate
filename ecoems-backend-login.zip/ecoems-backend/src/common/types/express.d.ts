import type { UserRole } from '@prisma/client';

export interface AuthenticatedUserPayload {
  userId: string;
  role: UserRole;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthenticatedUserPayload;
    }
  }
}

export {};
