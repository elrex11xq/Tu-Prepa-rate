import pino from 'pino';
import { env } from './env';

const baseOptions: pino.LoggerOptions = {
  level: env.NODE_ENV === 'production' ? 'info' : 'debug',
  redact: ['req.headers.authorization', 'password', 'passwordHash'],
};

export const logger = pino(
  env.NODE_ENV !== 'production'
    ? { ...baseOptions, transport: { target: 'pino-pretty', options: { colorize: true } } }
    : baseOptions,
);
