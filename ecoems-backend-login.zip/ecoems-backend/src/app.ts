import express, { type Application } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import pinoHttp from 'pino-http';
import { logger } from '@config/logger';
import { errorHandlerMiddleware, notFoundMiddleware } from '@common/errors/errorHandler.middleware';
import { apiRouter } from './routes';
import { subscriptionWebhookRouter } from '@modules/subscriptions/webhook.controller';

export function createApp(): Application {
  const app = express();

  app.use(helmet());
  app.use(cors());
  app.use(compression());
  app.use(pinoHttp({ logger }));

  // Rate limiting global (ajustable por ruta en cada módulo si se requiere algo más estricto,
  // p.ej. login con límites más agresivos contra fuerza bruta)
  app.use(
    rateLimit({
      windowMs: 15 * 60 * 1000,
      limit: 300,
      standardHeaders: true,
      legacyHeaders: false,
    }),
  );

  // IMPORTANTE: el webhook de Stripe necesita el body EN CRUDO (raw) para verificar
  // la firma, por lo que se monta ANTES del parser JSON global.
  app.use('/webhooks', subscriptionWebhookRouter);

  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true }));

  app.get('/health', (_req, res) => {
    res.status(200).json({ success: true, status: 'ok', timestamp: new Date().toISOString() });
  });

  app.use('/api/v1', apiRouter);

  app.use(notFoundMiddleware);
  app.use(errorHandlerMiddleware);

  return app;
}
