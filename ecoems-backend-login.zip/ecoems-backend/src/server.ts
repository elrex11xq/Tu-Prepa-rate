import 'module-alias/register';
import { createApp } from './app';
import { env } from '@config/env';
import { connectDatabase, disconnectDatabase } from '@config/database';
import { logger } from '@config/logger';

async function bootstrap(): Promise<void> {
  await connectDatabase();
  logger.info('✅ Conexión a base de datos establecida');

  const app = createApp();

  const server = app.listen(env.PORT, () => {
    logger.info(`🚀 ECOEMS backend escuchando en el puerto ${env.PORT} (${env.NODE_ENV})`);
  });

  const shutdown = async (signal: string): Promise<void> => {
    logger.info(`Recibida señal ${signal}, cerrando servidor...`);
    server.close(async () => {
      await disconnectDatabase();
      logger.info('Servidor cerrado correctamente');
      process.exit(0);
    });
  };

  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));
}

bootstrap().catch((err) => {
  logger.error({ err }, 'Error fatal al iniciar la aplicación');
  process.exit(1);
});
