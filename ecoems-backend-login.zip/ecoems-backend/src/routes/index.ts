import { Router } from 'express';
import { authRouter } from '@modules/auth/auth.routes';
import { userRouter } from '@modules/users/user.routes';
import { subscriptionRouter } from '@modules/subscriptions/subscription.routes';
import { questionRouter } from '@modules/questions/question.routes';
import { gameRouter } from '@modules/game/game.routes';

export const apiRouter = Router();

apiRouter.use('/auth', authRouter);
apiRouter.use('/users', userRouter);
apiRouter.use('/subscriptions', subscriptionRouter);
apiRouter.use('/questions', questionRouter);
apiRouter.use('/game', gameRouter);
