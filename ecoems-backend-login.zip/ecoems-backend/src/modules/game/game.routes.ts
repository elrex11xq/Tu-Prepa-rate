import { Router } from 'express';

export const gameRouter = Router();

/**
 * MÓDULO: MOTOR DE JUEGO Y PROGRESIÓN
 * Pendiente de implementación:
 *   POST  /game/sessions                 -> inicia sesión (LESSON | CHALLENGE | TIMED), valida vidas
 *   POST  /game/sessions/:id/answers     -> registra respuesta a un reactivo, valida y puntúa
 *   POST  /game/sessions/:id/finish      -> cierra sesión, calcula XP, actualiza racha y progreso
 *   GET   /game/sessions/:id             -> detalle/resultado de una sesión
 */
