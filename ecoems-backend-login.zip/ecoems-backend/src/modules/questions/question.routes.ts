import { Router } from 'express';

export const questionRouter = Router();

/**
 * MÓDULO: BANCO DE PREGUNTAS (ECOEMS)
 * Pendiente de implementación:
 *   GET    /questions/subjects              -> catálogo de materias
 *   GET    /questions/subjects/:id/topics   -> temas de una materia (con estado de progreso)
 *   GET    /questions/topics/:id/questions  -> reactivos de un tema (sin exponer isCorrect al cliente)
 *   [ADMIN] POST/PUT/DELETE para CRUD de materias/temas/reactivos/opciones
 */
