import { prisma } from '@config/database';
import { hashPassword, verifyPassword } from '@common/utils/password.util';
import {
  generateRefreshTokenJti,
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
} from '@common/utils/jwt.util';
import { hashToken } from '@common/utils/hashToken.util';
import { env } from '@config/env';
import { ConflictError, UnauthorizedError } from '@common/errors/AppError';
import { logger } from '@config/logger';
import type { RegisterInput, LoginInput } from './auth.schema';
import type { User } from '@prisma/client';

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

export interface SafeUser {
  id: string;
  email: string;
  username: string;
  role: User['role'];
  xp: number;
  level: number;
  currentStreak: number;
  lives: number;
  createdAt: Date;
}

function toSafeUser(user: User): SafeUser {
  return {
    id: user.id,
    email: user.email,
    username: user.username,
    role: user.role,
    xp: user.xp,
    level: user.level,
    currentStreak: user.currentStreak,
    lives: user.lives,
    createdAt: user.createdAt,
  };
}

function refreshExpiryDate(): Date {
  // Convierte el string tipo "30d"/"15m" de env a una fecha absoluta para persistir en DB.
  const match = /^(\d+)([smhd])$/.exec(env.JWT_REFRESH_EXPIRES_IN);
  const amount = match?.[1] ? Number(match[1]) : 30;
  const unit: string = match?.[2] ?? 'd';
  const unitMs: Record<string, number> = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 };
  const factor = unitMs[unit] ?? unitMs['d'] ?? 86_400_000;
  return new Date(Date.now() + amount * factor);
}

/**
 * Emite un par access/refresh token para un usuario y persiste el refresh
 * (hasheado) para poder revocarlo/rotarlo posteriormente.
 */
async function issueTokenPair(userId: string, role: User['role']): Promise<AuthTokens> {
  const accessToken = signAccessToken({ userId, role });

  const jti = generateRefreshTokenJti();
  const refreshToken = signRefreshToken({ userId, jti });

  await prisma.refreshToken.create({
    data: {
      userId,
      tokenHash: hashToken(refreshToken),
      expiresAt: refreshExpiryDate(),
    },
  });

  return { accessToken, refreshToken };
}

export async function registerUser(input: RegisterInput): Promise<{ user: SafeUser; tokens: AuthTokens }> {
  const existing = await prisma.user.findFirst({
    where: { OR: [{ email: input.email }, { username: input.username }] },
    select: { email: true, username: true },
  });

  if (existing) {
    if (existing.email === input.email) {
      throw new ConflictError('Ya existe una cuenta registrada con este email');
    }
    throw new ConflictError('El username ya está en uso');
  }

  const passwordHash = await hashPassword(input.password);

  const user = await prisma.user.create({
    data: {
      email: input.email,
      username: input.username,
      passwordHash,
    },
  });

  const tokens = await issueTokenPair(user.id, user.role);
  logger.info({ userId: user.id }, 'Nuevo usuario registrado');

  return { user: toSafeUser(user), tokens };
}

export async function loginUser(input: LoginInput): Promise<{ user: SafeUser; tokens: AuthTokens }> {
  const user = await prisma.user.findUnique({ where: { email: input.email } });

  // Mensaje genérico deliberado: no revelar si el email existe o no (evita enumeración de cuentas).
  const invalidCredentialsError = new UnauthorizedError('Email o contraseña incorrectos');

  if (!user || !user.isActive) {
    throw invalidCredentialsError;
  }

  const passwordMatches = await verifyPassword(user.passwordHash, input.password);
  if (!passwordMatches) {
    throw invalidCredentialsError;
  }

  const tokens = await issueTokenPair(user.id, user.role);
  return { user: toSafeUser(user), tokens };
}

/**
 * Rota el refresh token: valida firma JWT + estado en DB, revoca el token usado
 * y emite un par nuevo. Si el token presentado ya estaba revocado/reemplazado,
 * se interpreta como posible robo de token y se revocan TODAS las sesiones del usuario.
 */
export async function refreshTokens(rawRefreshToken: string): Promise<AuthTokens> {
  const payload = verifyRefreshToken(rawRefreshToken);
  const tokenHash = hashToken(rawRefreshToken);

  const storedToken = await prisma.refreshToken.findUnique({ where: { tokenHash } });

  if (!storedToken || storedToken.userId !== payload.userId) {
    throw new UnauthorizedError('Refresh token no reconocido');
  }

  if (storedToken.revokedAt) {
    // Reutilización de un token ya rotado: posible token robado -> revocar toda la sesión.
    logger.warn({ userId: payload.userId }, 'Reutilización de refresh token detectada; revocando sesiones');
    await prisma.refreshToken.updateMany({
      where: { userId: payload.userId, revokedAt: null },
      data: { revokedAt: new Date() },
    });
    throw new UnauthorizedError('Sesión inválida, por favor inicia sesión de nuevo');
  }

  if (storedToken.expiresAt < new Date()) {
    throw new UnauthorizedError('Refresh token expirado');
  }

  const user = await prisma.user.findUnique({ where: { id: payload.userId } });
  if (!user || !user.isActive) {
    throw new UnauthorizedError('Usuario no disponible');
  }

  return prisma.$transaction(async (tx) => {
    const newAccessToken = signAccessToken({ userId: user.id, role: user.role });
    const newJti = generateRefreshTokenJti();
    const newRefreshToken = signRefreshToken({ userId: user.id, jti: newJti });
    const newTokenHash = hashToken(newRefreshToken);

    const created = await tx.refreshToken.create({
      data: { userId: user.id, tokenHash: newTokenHash, expiresAt: refreshExpiryDate() },
    });

    await tx.refreshToken.update({
      where: { id: storedToken.id },
      data: { revokedAt: new Date(), replacedBy: created.id },
    });

    return { accessToken: newAccessToken, refreshToken: newRefreshToken };
  });
}

export async function logoutUser(rawRefreshToken: string): Promise<void> {
  const tokenHash = hashToken(rawRefreshToken);
  // No lanzamos error si no existe: el logout debe ser idempotente.
  await prisma.refreshToken.updateMany({
    where: { tokenHash, revokedAt: null },
    data: { revokedAt: new Date() },
  });
}

export async function getUserProfile(userId: string): Promise<SafeUser> {
  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  return toSafeUser(user);
}
