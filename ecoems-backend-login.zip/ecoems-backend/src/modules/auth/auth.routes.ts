import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { validate } from '@common/middlewares/validate.middleware';
import { requireAuth } from '@common/middlewares/auth.middleware';
import { loginSchema, logoutSchema, refreshSchema, registerSchema } from './auth.schema';
import * as authController from './auth.controller';

export const authRouter = Router();

/**
 * Rate limit estricto para endpoints sensibles a fuerza bruta / credential stuffing.
 * Más agresivo que el límite global de la app (definido en app.ts).
 */
const authBruteForceLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: { code: 'TOO_MANY_REQUESTS', message: 'Demasiados intentos, intenta más tarde' } },
});

authRouter.post(
  '/register',
  authBruteForceLimiter,
  validate({ body: registerSchema }),
  authController.register,
);

authRouter.post(
  '/login',
  authBruteForceLimiter,
  validate({ body: loginSchema }),
  authController.login,
);

authRouter.post('/refresh', validate({ body: refreshSchema }), authController.refresh);

authRouter.post('/logout', validate({ body: logoutSchema }), authController.logout);

authRouter.get('/me', requireAuth, authController.me);
