import type { Request, Response } from 'express';
import { asyncHandler } from '@common/utils/asyncHandler';
import * as authService from './auth.service';
import type { LoginInput, LogoutInput, RefreshInput, RegisterInput } from './auth.schema';
import { UnauthorizedError } from '@common/errors/AppError';

type NoParams = Record<string, string>;

export const register = asyncHandler<Request<NoParams, unknown, RegisterInput>>(async (req, res) => {
  const { user, tokens } = await authService.registerUser(req.body);
  res.status(201).json({ success: true, data: { user, ...tokens } });
});

export const login = asyncHandler<Request<NoParams, unknown, LoginInput>>(async (req, res) => {
  const { user, tokens } = await authService.loginUser(req.body);
  res.status(200).json({ success: true, data: { user, ...tokens } });
});

export const refresh = asyncHandler<Request<NoParams, unknown, RefreshInput>>(async (req, res) => {
  const tokens = await authService.refreshTokens(req.body.refreshToken);
  res.status(200).json({ success: true, data: tokens });
});

export const logout = asyncHandler<Request<NoParams, unknown, LogoutInput>>(async (req, res) => {
  await authService.logoutUser(req.body.refreshToken);
  res.status(204).send();
});

export const me = asyncHandler(async (req: Request, res: Response) => {
  if (!req.user) {
    throw new UnauthorizedError();
  }
  const profile = await authService.getUserProfile(req.user.userId);
  res.status(200).json({ success: true, data: profile });
});
