import { Router } from 'express';

export const subscriptionRouter = Router();

/**
 * MÓDULO: SUSCRIPCIONES (rutas autenticadas, distintas del webhook público)
 * Pendiente de implementación:
 *   POST  /subscriptions/checkout-session   -> crea sesión de pago (Stripe Checkout)
 *   GET   /subscriptions/me                 -> estado actual de la suscripción
 *   POST  /subscriptions/cancel             -> solicita cancelación al finalizar periodo
 */
