import { Router } from 'express';

export const subscriptionWebhookRouter = Router();

/**
 * MÓDULO: WEBHOOKS DE PAGOS
 * Pendiente de implementación:
 *   POST  /webhooks/stripe   -> requiere express.raw() (NO json parser) para validar firma
 * Debe garantizar:
 *   - Verificación de firma (stripe.webhooks.constructEvent)
 *   - Idempotencia vía tabla WebhookEvent (eventId único)
 *   - Transacción atómica al actualizar Subscription + PaymentTransaction
 */
