import { Router } from 'express';

export const userRouter = Router();

/**
 * MÓDULO: PERFIL Y ESTADÍSTICAS DE USUARIO
 * Pendiente de implementación:
 *   GET   /users/me/stats        -> XP, racha, vidas actuales
 *   PATCH /users/me/stats        -> actualización de estadísticas (uso interno del motor de juego)
 *   GET   /users/me/progress     -> progreso por tema/materia
 */
