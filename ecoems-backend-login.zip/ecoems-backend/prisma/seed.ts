import { PrismaClient, QuestionDifficulty } from '@prisma/client';

const prisma = new PrismaClient();

async function main(): Promise<void> {
  const subject = await prisma.subject.upsert({
    where: { slug: 'urgencias-medico-quirurgicas' },
    update: {},
    create: {
      name: 'Urgencias Médico-Quirúrgicas',
      slug: 'urgencias-medico-quirurgicas',
      description: 'Manejo de urgencias en el primer nivel de atención',
      order: 1,
    },
  });

  const topic = await prisma.topic.upsert({
    where: { subjectId_slug: { subjectId: subject.id, slug: 'politraumatizado' } },
    update: {},
    create: {
      subjectId: subject.id,
      name: 'Manejo Inicial del Politraumatizado',
      slug: 'politraumatizado',
      order: 1,
    },
  });

  await prisma.question.create({
    data: {
      topicId: topic.id,
      statement:
        'Paciente masculino de 28 años, ingresa tras colisión vehicular con TA 80/50 mmHg y FC 128 lpm. ¿Cuál es la prioridad inmediata?',
      difficulty: QuestionDifficulty.MEDIUM,
      explanation:
        'El paciente presenta datos de choque hipovolémico; la prioridad es asegurar la vía aérea y controlar hemorragias activas antes de la reanimación con líquidos (secuencia ABCDE).',
      options: {
        create: [
          { text: 'Iniciar reanimación con cristaloides de inmediato', order: 1, isCorrect: false },
          { text: 'Evaluar y asegurar la vía aérea, controlar hemorragia externa', order: 2, isCorrect: true },
          { text: 'Solicitar tomografía de cráneo urgente', order: 3, isCorrect: false },
          { text: 'Administrar analgésico opioide antes de valorar signos vitales', order: 4, isCorrect: false },
        ],
      },
    },
  });

  // eslint-disable-next-line no-console
  console.log('✅ Seed completado: 1 materia, 1 tema, 1 reactivo de ejemplo');
}

main()
  .catch((e) => {
    // eslint-disable-next-line no-console
    console.error(e);
    process.exit(1);
  })
  .finally(() => {
    void prisma.$disconnect();
  });
