# ECOEMS App — Backend

Backend modular para una plataforma gamificada de preparación para el examen **ECOEMS** (estilo Duolingo/Preguntados).

## Stack

| Capa | Tecnología | Motivo |
|---|---|---|
| Runtime | Node.js 20+ / TypeScript (strict) | Tipado estricto de extremo a extremo |
| Framework HTTP | Express 4 | Madurez, control fino de middlewares |
| Base de datos | PostgreSQL | Integridad relacional, transacciones ACID (crítico en pagos y puntajes) |
| ORM / Migraciones | Prisma | Migraciones versionadas + cliente tipado generado desde el esquema |
| Auth | JWT (access + refresh rotativo) | Stateless, escalable horizontalmente |
| Pagos | Stripe (Checkout + Webhooks) | Estándar de mercado, checkout hospedado |
| Validación | Zod | Validación y tipado inferido en un solo esquema |
| Logging | Pino | Logging estructurado de bajo overhead |

## Estructura de carpetas

```
ecoems-backend/
├── prisma/
│   ├── schema.prisma        # Esquema completo (fuente de la migración inicial)
│   └── seed.ts               # Datos de ejemplo para el banco de preguntas
├── src/
│   ├── config/                # env, database (Prisma singleton), logger
│   ├── common/
│   │   ├── errors/            # AppError + jerarquía + errorHandler global
│   │   ├── middlewares/       # validate (Zod), auth (JWT) [pendiente], rateLimiter
│   │   ├── types/              # Extensión de Request de Express (req.user)
│   │   └── utils/              # asyncHandler, jwt.util [pendiente], password.util [pendiente]
│   ├── modules/
│   │   ├── auth/                # Registro, login, refresh, logout
│   │   ├── users/                # Perfil, XP, racha, vidas
│   │   ├── subscriptions/        # Checkout + estado de suscripción + webhook.controller.ts
│   │   ├── questions/             # Materias, temas, reactivos, opciones
│   │   └── game/                   # Sesiones de juego, scoring, progreso
│   ├── routes/index.ts        # Router raíz que agrupa todos los módulos
│   ├── app.ts                   # Ensamblaje de Express + middlewares de seguridad
│   └── server.ts                # Bootstrap + graceful shutdown
├── .env.example
├── package.json
└── tsconfig.json
```

Cada módulo sigue el mismo patrón interno (Router → Controller → Service → Prisma), separando:
- **routes**: definición de endpoints + middlewares de validación/auth.
- **controller**: adaptador HTTP (parsea request, llama al service, formatea response).
- **service**: lógica de negocio pura, reutilizable y testeable, con transacciones (`prisma.$transaction`) cuando hay escritura multi-tabla.
- **schema**: esquemas Zod (entrada) reutilizados también como DTOs de salida cuando aplica.

## Modelo de datos — resumen por pilar

1. **Identidad**: `User`, `RefreshToken`. XP, racha y vidas viven directamente en `User` para lecturas O(1) en el home de la app; el detalle histórico de partidas vive en `GameSession`.
2. **Pagos**: `Subscription` (estado actual, 1:1 con usuario), `PaymentTransaction` (histórico auditable), `WebhookEvent` (idempotencia — clave para no duplicar altas/bajas si Stripe reintenta la entrega).
3. **Contenido**: `Subject` → `Topic` → `Question` → `AnswerOption`, jerarquía que refleja el temario ECOEMS y permite armar el árbol de lecciones estilo Duolingo (`Topic.unlockAfterTopicId`).
4. **Juego/Progresión**: `UserTopicProgress` (estado agregado y persistente por tema, usado para desbloqueo), `GameSession` + `GameSessionAnswer` (cada partida y cada respuesta individual, auditable y útil para analítica de reactivos difíciles).

## Decisiones de robustez transaccional

- Cualquier operación que module **estado de negocio + dinero** (webhook de Stripe) o **estado de negocio + XP/vidas/progreso** (cierre de una sesión de juego) debe ejecutarse dentro de `prisma.$transaction(...)` para garantizar atomicidad.
- Los webhooks se registran primero en `WebhookEvent` (idempotencia por `eventId` único) antes de aplicar efectos secundarios.
- Los errores se modelan como una jerarquía tipada (`AppError` y subclases) capturada por un único `errorHandlerMiddleware`, que también traduce errores conocidos de Prisma (`P2002`, `P2025`, `P2003`) y de Zod a respuestas HTTP consistentes.

## Cómo levantar el proyecto

```bash
cp .env.example .env      # completar secretos reales
npm install
npm run prisma:migrate    # crea la migración inicial a partir de schema.prisma
npm run prisma:seed       # opcional: datos de ejemplo
npm run dev
```

## Estado actual

✅ Arquitectura de carpetas
✅ Esquema de base de datos completo (los 4 pilares)
✅ Infraestructura transversal: config, manejo de errores, validación, logging, seguridad HTTP base
⏳ Lógica de negocio de cada módulo — **pendiente de desarrollo módulo por módulo**, en el orden que se priorice.

## Próximo paso

Indicar qué módulo desarrollar primero:
1. **Auth** (JWT, registro/login, refresh rotativo) — normalmente el bloqueante de todo lo demás.
2. **Banco de preguntas** — CRUD de materias/temas/reactivos.
3. **Motor de juego** — validación de respuestas, scoring, vidas, progreso.
4. **Pagos/Webhooks** — Stripe Checkout + manejo de eventos.
