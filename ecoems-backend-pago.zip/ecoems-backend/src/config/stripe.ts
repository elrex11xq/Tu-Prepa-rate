import Stripe from 'stripe';
import { env } from './env';

/**
 * Cliente Stripe centralizado. Fijamos una apiVersion explícita para que
 * actualizaciones futuras del SDK/cuenta de Stripe no cambien silenciosamente
 * la forma de los payloads que recibimos en los webhooks.
 */
export const stripe = new Stripe(env.STRIPE_SECRET_KEY, {
  apiVersion: '2024-06-20',
  typescript: true,
});
