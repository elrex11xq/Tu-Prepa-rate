import { Router, raw } from 'express';
import type Stripe from 'stripe';
import { Prisma, type PrismaClient } from '@prisma/client';
import { stripe } from '@config/stripe';
import { env } from '@config/env';
import { prisma } from '@config/database';
import { logger } from '@config/logger';
import { asyncHandler } from '@common/utils/asyncHandler';
import { BadRequestError } from '@common/errors/AppError';
import { mapStripeStatus, planForPriceId } from './subscription.service';

export const subscriptionWebhookRouter = Router();

type TxClient = Omit<PrismaClient, '$connect' | '$disconnect' | '$on' | '$transaction' | '$use' | '$extends'>;

/**
 * Endpoint de webhooks de Stripe.
 * CRÍTICO: usa `express.raw()` (body como Buffer sin parsear) en vez del
 * `express.json()` global, porque la verificación de firma de Stripe
 * necesita el payload EXACTO tal como fue enviado, byte por byte.
 */
subscriptionWebhookRouter.post(
  '/stripe',
  raw({ type: 'application/json' }),
  asyncHandler(async (req, res) => {
    const signature = req.headers['stripe-signature'];
    if (typeof signature !== 'string') {
      throw new BadRequestError('Falta el encabezado stripe-signature');
    }

    let event: Stripe.Event;
    try {
      event = stripe.webhooks.constructEvent(req.body as Buffer, signature, env.STRIPE_WEBHOOK_SECRET);
    } catch (err) {
      logger.warn({ err }, 'Firma de webhook de Stripe inválida — posible solicitud falsificada');
      throw new BadRequestError('Firma de webhook inválida');
    }

    await processStripeEvent(event);

    // Responder 200 rápidamente: Stripe reintenta agresivamente si no recibe 2xx a tiempo.
    res.status(200).json({ received: true });
  }),
);

function isDuplicateEventError(err: unknown): boolean {
  return err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2002';
}

/**
 * Procesa un evento de Stripe de forma atómica e idempotente:
 * 1. Inserta el evento en `WebhookEvent` (eventId es UNIQUE) DENTRO de la misma
 *    transacción que aplica sus efectos. Si el evento ya fue procesado antes,
 *    la inserción falla por constraint único y TODA la transacción se revierte,
 *    dejando el estado exactamente como si nunca hubiéramos recibido el duplicado.
 * 2. Si algo falla a mitad de camino, también se revierte todo, permitiendo que
 *    el reintento automático de Stripe reprocese el evento desde cero de forma segura.
 */
async function processStripeEvent(event: Stripe.Event): Promise<void> {
  try {
    await prisma.$transaction(async (tx) => {
      await tx.webhookEvent.create({
        data: {
          provider: 'stripe',
          eventId: event.id,
          eventType: event.type,
          payload: event as unknown as Prisma.InputJsonValue,
        },
      });

      switch (event.type) {
        case 'customer.subscription.created':
        case 'customer.subscription.updated':
          await handleSubscriptionUpsert(tx, event.data.object as Stripe.Subscription);
          break;

        case 'customer.subscription.deleted':
          await handleSubscriptionDeleted(tx, event.data.object as Stripe.Subscription);
          break;

        case 'invoice.paid':
        case 'invoice.payment_succeeded':
          await handleInvoiceOutcome(tx, event.data.object as Stripe.Invoice, 'succeeded');
          break;

        case 'invoice.payment_failed':
          await handleInvoiceOutcome(tx, event.data.object as Stripe.Invoice, 'failed');
          break;

        default:
          logger.info({ type: event.type }, 'Evento de Stripe recibido sin manejador específico (ignorado)');
      }

      await tx.webhookEvent.update({
        where: { eventId: event.id },
        data: { processedAt: new Date() },
      });
    });
  } catch (err) {
    if (isDuplicateEventError(err)) {
      logger.info({ eventId: event.id, type: event.type }, 'Evento de webhook duplicado ignorado (idempotencia)');
      return;
    }
    // Cualquier otro error se propaga: el asyncHandler lo convierte en 5xx,
    // lo que hace que Stripe reintente la entrega más tarde.
    logger.error({ err, eventId: event.id, type: event.type }, 'Error procesando evento de webhook de Stripe');
    throw err;
  }
}

async function resolveUserIdForCustomer(
  tx: TxClient,
  customerId: string,
  metadataUserId: string | undefined,
): Promise<string> {
  if (metadataUserId) {
    return metadataUserId;
  }
  const existing = await tx.subscription.findFirst({ where: { providerCustomerId: customerId } });
  if (!existing) {
    throw new Error(`No se pudo resolver el userId para el customer de Stripe ${customerId}`);
  }
  return existing.userId;
}

async function handleSubscriptionUpsert(tx: TxClient, subscription: Stripe.Subscription): Promise<void> {
  const customerId = typeof subscription.customer === 'string' ? subscription.customer : subscription.customer.id;
  const userId = await resolveUserIdForCustomer(tx, customerId, subscription.metadata?.userId);

  const priceId = subscription.items.data[0]?.price.id;
  const plan = priceId ? planForPriceId(priceId) : undefined;
  const status = mapStripeStatus(subscription.status);
  const currentPeriodStart = new Date(subscription.current_period_start * 1000);
  const currentPeriodEnd = new Date(subscription.current_period_end * 1000);

  await tx.subscription.upsert({
    where: { userId },
    create: {
      userId,
      provider: 'stripe',
      providerCustomerId: customerId,
      providerSubscriptionId: subscription.id,
      plan: plan ?? 'MONTHLY',
      status,
      currentPeriodStart,
      currentPeriodEnd,
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
    },
    update: {
      providerSubscriptionId: subscription.id,
      ...(plan ? { plan } : {}),
      status,
      currentPeriodStart,
      currentPeriodEnd,
      cancelAtPeriodEnd: subscription.cancel_at_period_end,
    },
  });
}

async function handleSubscriptionDeleted(tx: TxClient, subscription: Stripe.Subscription): Promise<void> {
  const customerId = typeof subscription.customer === 'string' ? subscription.customer : subscription.customer.id;
  const existing = await tx.subscription.findFirst({ where: { providerCustomerId: customerId } });

  if (!existing) {
    logger.warn({ customerId }, 'customer.subscription.deleted recibido sin registro local correspondiente');
    return;
  }

  await tx.subscription.update({
    where: { userId: existing.userId },
    data: { status: 'CANCELED', canceledAt: new Date(), cancelAtPeriodEnd: true },
  });
}

async function handleInvoiceOutcome(
  tx: TxClient,
  invoice: Stripe.Invoice,
  outcome: 'succeeded' | 'failed',
): Promise<void> {
  const customerId = typeof invoice.customer === 'string' ? invoice.customer : invoice.customer?.id;
  const existing = customerId
    ? await tx.subscription.findFirst({ where: { providerCustomerId: customerId } })
    : null;

  await tx.paymentTransaction.create({
    data: {
      userId: existing?.userId ?? null,
      provider: 'stripe',
      providerRefId: invoice.id,
      amountCents: outcome === 'succeeded' ? invoice.amount_paid : invoice.amount_due,
      currency: invoice.currency.toUpperCase(),
      status: outcome,
      rawPayload: invoice as unknown as Prisma.InputJsonValue,
    },
  });

  if (outcome === 'failed') {
    logger.warn({ userId: existing?.userId, invoiceId: invoice.id }, 'Pago de invoice fallido');
  }
}
