import type { Subscription, SubscriptionPlan, SubscriptionStatus } from '@prisma/client';
import { prisma } from '@config/database';
import { stripe } from '@config/stripe';
import { env } from '@config/env';
import { logger } from '@config/logger';
import { AppError, NotFoundError } from '@common/errors/AppError';

type PayablePlan = Extract<SubscriptionPlan, 'MONTHLY' | 'ANNUAL'>;

/** Traduce nuestro enum de plan a un Price ID real de Stripe (configurado por entorno). */
export function priceIdForPlan(plan: PayablePlan): string {
  const mapping: Record<PayablePlan, string> = {
    MONTHLY: env.STRIPE_PRICE_MONTHLY,
    ANNUAL: env.STRIPE_PRICE_ANNUAL,
  };
  return mapping[plan];
}

/** Traduce un Price ID de Stripe de vuelta a nuestro enum de plan (usado al procesar webhooks). */
export function planForPriceId(priceId: string): PayablePlan | undefined {
  if (priceId === env.STRIPE_PRICE_MONTHLY) return 'MONTHLY';
  if (priceId === env.STRIPE_PRICE_ANNUAL) return 'ANNUAL';
  return undefined;
}

/** Traduce el status de Stripe a nuestro enum interno de SubscriptionStatus. */
export function mapStripeStatus(stripeStatus: string): SubscriptionStatus {
  const mapping: Record<string, SubscriptionStatus> = {
    trialing: 'TRIALING',
    active: 'ACTIVE',
    past_due: 'PAST_DUE',
    canceled: 'CANCELED',
    unpaid: 'UNPAID',
    incomplete: 'INCOMPLETE',
    incomplete_expired: 'CANCELED',
  };
  return mapping[stripeStatus] ?? 'INCOMPLETE';
}

export interface SubscriptionSummary {
  plan: SubscriptionPlan;
  status: SubscriptionStatus;
  currentPeriodEnd: Date | null;
  cancelAtPeriodEnd: boolean;
}

function toSummary(sub: Subscription): SubscriptionSummary {
  return {
    plan: sub.plan,
    status: sub.status,
    currentPeriodEnd: sub.currentPeriodEnd,
    cancelAtPeriodEnd: sub.cancelAtPeriodEnd,
  };
}

/**
 * Garantiza que el usuario tenga un customer de Stripe y un registro local
 * de Subscription (placeholder en estado INCOMPLETE hasta que el pago se confirme
 * vía webhook). Es idempotente: si ya existe, lo reutiliza.
 */
async function ensureLocalSubscriptionAndCustomer(userId: string): Promise<Subscription> {
  const existing = await prisma.subscription.findUnique({ where: { userId } });
  if (existing) {
    return existing;
  }

  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  const customer = await stripe.customers.create({
    email: user.email,
    metadata: { userId },
  });

  return prisma.subscription.create({
    data: {
      userId,
      provider: 'stripe',
      providerCustomerId: customer.id,
      plan: 'FREE',
      status: 'INCOMPLETE',
    },
  });
}

/**
 * Crea una sesión de Stripe Checkout para iniciar/actualizar una suscripción.
 * El estado real (ACTIVE, periodos, etc.) se confirma exclusivamente vía webhook,
 * nunca se marca como pagado directamente aquí (evita inconsistencias si el
 * usuario cierra el navegador antes de completar el pago).
 */
export async function createCheckoutSession(userId: string, plan: PayablePlan): Promise<{ url: string }> {
  const subscriptionRow = await ensureLocalSubscriptionAndCustomer(userId);

  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    customer: subscriptionRow.providerCustomerId,
    line_items: [{ price: priceIdForPlan(plan), quantity: 1 }],
    success_url: `${env.FRONTEND_URL}/subscription/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${env.FRONTEND_URL}/subscription/cancel`,
    subscription_data: { metadata: { userId } },
    metadata: { userId },
    allow_promotion_codes: true,
  });

  if (!session.url) {
    logger.error({ userId, sessionId: session.id }, 'Stripe no devolvió una URL de checkout');
    throw new AppError('No se pudo iniciar el proceso de pago, intenta de nuevo', 502, 'STRIPE_CHECKOUT_ERROR');
  }

  return { url: session.url };
}

export async function getMySubscription(userId: string): Promise<SubscriptionSummary> {
  const subscriptionRow = await prisma.subscription.findUnique({ where: { userId } });

  if (!subscriptionRow) {
    // Sin registro aún = usuario en plan gratuito por defecto.
    return { plan: 'FREE', status: 'ACTIVE', currentPeriodEnd: null, cancelAtPeriodEnd: false };
  }

  return toSummary(subscriptionRow);
}

/**
 * Solicita la cancelación al FINAL del periodo ya pagado (no una cancelación
 * inmediata), que es el comportamiento esperado por el usuario en apps de suscripción.
 */
export async function requestCancelSubscription(userId: string): Promise<SubscriptionSummary> {
  const subscriptionRow = await prisma.subscription.findUnique({ where: { userId } });

  if (!subscriptionRow?.providerSubscriptionId) {
    throw new NotFoundError('Suscripción activa');
  }

  const updatedStripeSub = await stripe.subscriptions.update(subscriptionRow.providerSubscriptionId, {
    cancel_at_period_end: true,
  });

  const updated = await prisma.subscription.update({
    where: { userId },
    data: { cancelAtPeriodEnd: true },
  });

  logger.info({ userId, subscriptionId: updatedStripeSub.id }, 'Cancelación de suscripción solicitada');

  return toSummary(updated);
}
