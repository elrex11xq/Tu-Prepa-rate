import { z } from 'zod';

export const checkoutSessionSchema = z.object({
  plan: z.enum(['MONTHLY', 'ANNUAL'], {
    errorMap: () => ({ message: 'plan debe ser MONTHLY o ANNUAL' }),
  }),
});
export type CheckoutSessionInput = z.infer<typeof checkoutSessionSchema>;
