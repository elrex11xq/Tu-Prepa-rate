import { Router } from 'express';
import { requireAuth } from '@common/middlewares/auth.middleware';
import { validate } from '@common/middlewares/validate.middleware';
import { checkoutSessionSchema } from './subscription.schema';
import * as subscriptionController from './subscription.controller';

export const subscriptionRouter = Router();

// Todas las rutas de este router requieren un usuario autenticado.
subscriptionRouter.use(requireAuth);

subscriptionRouter.post(
  '/checkout-session',
  validate({ body: checkoutSessionSchema }),
  subscriptionController.createCheckoutSession,
);

subscriptionRouter.get('/me', subscriptionController.getMySubscription);

subscriptionRouter.post('/cancel', subscriptionController.cancelSubscription);
