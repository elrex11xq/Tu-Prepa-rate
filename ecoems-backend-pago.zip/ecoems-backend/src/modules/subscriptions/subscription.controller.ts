import type { Request, Response } from 'express';
import { asyncHandler } from '@common/utils/asyncHandler';
import { UnauthorizedError } from '@common/errors/AppError';
import * as subscriptionService from './subscription.service';
import type { CheckoutSessionInput } from './subscription.schema';

type NoParams = Record<string, string>;

export const createCheckoutSession = asyncHandler<Request<NoParams, unknown, CheckoutSessionInput>>(
  async (req, res) => {
    if (!req.user) throw new UnauthorizedError();
    const result = await subscriptionService.createCheckoutSession(req.user.userId, req.body.plan);
    res.status(200).json({ success: true, data: result });
  },
);

export const getMySubscription = asyncHandler(async (req: Request, res: Response) => {
  if (!req.user) throw new UnauthorizedError();
  const data = await subscriptionService.getMySubscription(req.user.userId);
  res.status(200).json({ success: true, data });
});

export const cancelSubscription = asyncHandler(async (req: Request, res: Response) => {
  if (!req.user) throw new UnauthorizedError();
  const data = await subscriptionService.requestCancelSubscription(req.user.userId);
  res.status(200).json({ success: true, data });
});
