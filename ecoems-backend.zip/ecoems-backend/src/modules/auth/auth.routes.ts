import { Router } from 'express';

export const authRouter = Router();

/**
 * MÓDULO: AUTENTICACIÓN Y PERFIL
 * Pendiente de implementación (siguiente paso a solicitar):
 *   POST   /auth/register        -> registro de usuario
 *   POST   /auth/login           -> login + emisión de access/refresh token
 *   POST   /auth/refresh         -> rotación de refresh token
 *   POST   /auth/logout          -> revocación de refresh token
 *   GET    /auth/me              -> perfil del usuario autenticado (requiere JWT)
 */
